$(document).ready(function(){
    
    $("#drops a").click(function(e){
        e.preventDefault();
        $("#app_drop").fadeToggle("slow");
		console.log( "You clicked you sly dog!" );
    });
    
     $("#drops a").click(function(){
        $("#drop_the_butt").toggleClass("active");
		console.log( "You clicked AGAIN you sinner!!" );
    });
    
    function ConvertFormToJSON(form){
        var array = $(form).serializeArray();
        var json = {};

        jQuery.each(array, function() {
            json[this.name] = this.value || '';
        });
        return json;
    }

//LOGIN
    function doLogin(e){


        e.preventDefault();        
        var email= $("#email").val();
        var pass= $("#pass").val();

        var formData = ConvertFormToJSON("#loginForm");
        console.log(formData);
        $.ajax({
            url: "../login.php",
            type: "POST",
            dataType: "JSON",
            data: {
                email: email,
                password: pass
            },
            success: function(resp){ 
                var status = resp['status'];
                if(status == 'error'){
                    $("#respdiv").show();
                    $("#respdiv").html(resp['msg'][0]['text']);

                } else {
                    $("#loginform").hide();
                    $("#admin_table").show();
                    $("#respdiv").show();
                    $("#respdiv").html("<h3>Welcome back, " + resp['user']['username'] + "!</h3><button id='logoutsub'>Logout</button>");
                    console.log(resp['user']['username']);
                }
            }
        });
    }
    $("#loginsub").click(doLogin);     

//LOGOUT
});