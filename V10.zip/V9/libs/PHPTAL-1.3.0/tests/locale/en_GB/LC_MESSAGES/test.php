<?php
return array(
    '' => 'Content-Type: text/plain; charset=utf-8
Content-Transfer-Encoding: 8bit
',
    'hello world' => 'hello world',
    'my first translate key' => 'First message translation test passed',
    'my second translate key' => 'Second test with login=${login} and lastCxDate=${lastCxDate} passed',
    'Welcome ${login}, your last connection date was : ${lastCxDate}' => 'Welcome ${login}, your last connection date was : ${lastCxDate}',
);
