<!DOCTYPE html>
<html>
<body>
    <div id="loginform">
        <form id="loginForm">
            <span>Email:</span><input type="text" id="email"/>
            <span>Password:</span><input type="password" id="pass"/>
            <button id="loginsub">Login</button>
        </form>
    </div> 
            <div id="respdiv" style="display:none">
                <button id="logoutsub">Logout</button>
            </div>
    
    <table id="admin_table" style="display:none">
  <thead>
    <tr>
    <th>Products</th>
        <th>Quantity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Apparel</td>
        <td>100</td>
    </tr>
    <tr>
        <td>Prints</td>
        <td>80</td>
    </tr>
    <tr>
        <td>Accessories</td>
        <td>500</td>
    </tr>
  </tbody>
  <tfoot>
    <tr>
        <td>Total Inventory</td>
        <td>180 something</td>
    </tr>
  </tfoot>

    </table>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="../js/main.js"></script>
</html>

